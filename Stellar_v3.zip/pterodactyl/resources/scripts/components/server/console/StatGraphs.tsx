import React, { useEffect, useMemo, useState, useRef } from 'react';
import { ServerContext } from '@/state/server';
import { SocketEvent, SocketRequest } from '@/components/server/events';
import useWebsocketEvent from '@/plugins/useWebsocketEvent';
import { Line } from 'react-chartjs-2';
import { useChart } from '@/components/server/console/chart';
import { bytesToString } from '@/lib/formatters';
import ChartBlock from '@/components/server/console/ChartBlock';

type Stats = Record<'rx' | 'tx', number>;

export default () => {
    const [stats, setStats] = useState<Stats>({ tx: 0, rx: 0 });
    const status = ServerContext.useStoreState((state) => state.status.value);
    const connected = ServerContext.useStoreState((state) => state.socket.connected);
    const instance = ServerContext.useStoreState((state) => state.socket.instance);
    const previous = useRef<Record<'tx' | 'rx', number>>({ tx: -1, rx: -1 });

    useEffect(() => {
        if (!connected || !instance) {
            return;
        }

        instance.send(SocketRequest.SEND_STATS);
    }, [instance, connected]);

    useWebsocketEvent(SocketEvent.STATS, (data) => {
        let stats: any = {};
        try {
            stats = JSON.parse(data);
        } catch (e) {
            return;
        }

        setStats({
            tx: stats.network.tx_bytes,
            rx: stats.network.rx_bytes
        });
    });

    const inbound = useChart('Inbound', {
        sets: 1,
        options: {
            scales: {
                y: {
                    ticks: {
                        callback(value) {
                            return bytesToString(typeof value === 'string' ? parseInt(value, 10) : value);
                        },
                    },
                },
            },
        },
    });

    const outbound = useChart('outbound', {
        sets: 1,
        options: {
            scales: {
                y: {
                    ticks: {
                        callback(value) {
                            return bytesToString(typeof value === 'string' ? parseInt(value, 10) : value);
                        },
                    },
                },
            },
        },
    });

    useEffect(() => {
        if (status === 'offline') {
            inbound.clear();
            outbound.clear();
        }
    }, [status]);

    useWebsocketEvent(SocketEvent.STATS, (data: string) => {
        let values: any = {};
        try {
            values = JSON.parse(data);
        } catch (e) {
            return;
        }

        inbound.push([
            previous.current.rx < 0 ? 0 : Math.max(0, values.network.rx_bytes - previous.current.rx),
        ]);
        outbound.push([
            previous.current.rx < 0 ? 0 : Math.max(0, values.network.tx_bytes - previous.current.tx),
        ]);

        previous.current = { tx: values.network.tx_bytes, rx: values.network.rx_bytes };
    });

    return (
        <>
            <ChartBlock title={'Data Inbound'}>
                <Line {...inbound.props} />
            </ChartBlock>
            <ChartBlock title={'Data Outbound'}>
                <Line {...outbound.props} />
            </ChartBlock>
        </>
    );
};
