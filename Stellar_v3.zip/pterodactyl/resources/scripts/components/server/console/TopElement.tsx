import React from 'react';
import { ServerContext } from '@/state/server';
import styled from 'styled-components/macro';
import CopyOnClick from '@/components/elements/CopyOnClick';
import { ip } from '@/lib/formatters';

const DetailsItem = styled.div`
    position:relative;
    background-color:var(--secondary);
    border-radius:20px;
    overflow:hidden;
    margin-bottom:10px;
    padding:15px 30px;
`;

const TopElement = () => {
    const name = ServerContext.useStoreState(state => state.server.data!.name);
    const allocation = ServerContext.useStoreState((state) => {
        const match = state.server.data!.allocations.find((allocation) => allocation.isDefault);

        return !match ? 'n/a' : `${match.alias || ip(match.ip)}:${match.port}`;
    });

    return (
        <DetailsItem>
            <h1 className='text-2xl'>{name}</h1>
            <CopyOnClick text={allocation}>
                <p className={`mt-2 mb-2`}>
                    IP: <span>{allocation}</span>
                </p>
            </CopyOnClick>
        </DetailsItem>
    );
};

export default TopElement;
